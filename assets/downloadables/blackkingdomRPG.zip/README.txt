__________.__                __
\______   \ | _____    ____ |  | __
|    |  _/  | \__  \ _/ ___\|  |/ /
|    |   \  |__/ __ \\  \___|    <
|______  /____(____  /\___  >__|_ \
       \/          \/     \/     \/
  ____  __.__                   .___
 |    |/ _|__| ____    ____   __| _/____   _____
 |      < |  |/    \  / ___\ / __ |/  _ \ /     \
 |    |  \|  |   |  \/ /_/  > /_/ (  <_> )  Y Y  \
 |____|__ \__|___|  /\___  /\____ |\____/|__|_|  /
         \/       \//_____/      \/            \/

A simple text-game RPG


How to install:

Download the .exe file to your machine. Double-clicking this will run a Python script in your terminal in which the game is played.

The terminal will prompt you for actions to take which are inputs from your keyboard.

I swear this isn't a virus, I am merely too lazy to port this over to a non-executable play format at this time. Just tell Windows Defender to shut it and run it anyway.


How to play:

#################################################
#                  Actions Menu                 #
#################################################
#                                               #
#  Interact with the game by typing commands.   #
#                                               #
#  - 'Look' describes the current scene.        #
#                                               #
#  - 'Attack' cycles through things you can     #
#     fight in the scene.                       #
#                                               #
#  - 'inventory' shows your current items and   #
#     stats.                                    #
#                                               #
#  - 'proceed' checks to see if you can move to #
#     the next area.                            #
#                                               #
#  - 'equip' to cycle through equipable items.  #
#                                               #
#  - 'talk' to cycle through NPCs or objects    #
#     you can interact with.                    #
#################################################



Extra files:

Raw Python file included if you wanna mess around with it.

I made this when just learning to code so there's approximately 1 trillion efficiencies to be made.